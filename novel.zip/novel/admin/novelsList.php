<?php
    include 'functions.php';
    if(empty($_SESSION['suser']))
    {
      echo "<script>location.href='index.php';</script>";
      exit;
    }
    getHeader();
    getSideBar();
    $allNovels = getAllNovels();
 ?>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
 <script>
   function addChapter(row_id)
   {
     location.href="addChapter.php?row_id="+row_id;
   }

   /*function blockUser(row_id)
    {
      $.post(
        'ajax.php',
        'block_user_id='+row_id,
        function(response)
        {
          if(response == 1)
          {
            alert("User has been blocked successfully!");
            location.reload();
          }
        }
      );
    }*/
 </script>
 <!-- Content Wrapper. Contains page content -->
 <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Users List</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="dashboard.php">Home</a></li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Novels List</h3>
              </div>
              <!-- /.card-header -->
              <!-- content start -->
              <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <th>Name</th>
                        <th>Author Name</th>
                        <th>Action</th>
                        
                    </tr>
                    </thead>
                    <tbody>
                    <?php
                        $i = 1;
                        while($row = mysqli_fetch_array($allNovels))
                        {
                          ?>
                          <tr>
                            <td><?php echo '('.$i.'.)'; ?></td>
                            <td><?php echo $row['name']; ?></td>
                            <td>
                                <?php
                                    $author_id = $row['author_id'];
                                    $authorData = getAuthorDataById($author_id);
                                    $authorData = mysqli_fetch_array($authorData);
                                    echo $authorData['name'];
                                ?>
                            </td>
                            <td>
                                <button type="button" class="btn btn-primary" onclick="addChapter(<?php echo $row['id']; ?>)">Add Chapter</button>
                                <button type="button" class="btn btn-danger" onclick="deleteNovel(<?php echo $row['id']; ?>)"><i class="fa fa-trash"></i></button>
                            </td>
                          </tr>
                          <?php
                          $i++;
                        }
                       ?>
                    </tbody>
                </table>

              <!-- content end ---->
            </div>
            <!-- /.card -->
          </div>
          <!--/.col (left) -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <?php getFooter(); ?>