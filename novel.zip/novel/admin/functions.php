<?php
    session_start();

    function OpenCon()
    {
        $dbhost = "localhost";
        $dbuser = "root";
        $dbpass = "";
        $db = "novel";
        $conn = new mysqli($dbhost, $dbuser, $dbpass,$db) or die("Connect failed: %s\n". $conn -> error);
        return $conn;
    }
    
    function CloseCon($conn)
    {
        $conn -> close();
    }

    function getHeader()
    {
        include 'header.php';
    }

    function getFooter()
    {
        include 'footer.php';
    }

    function getSideBar()
    {
        include 'sidebar.php';
    }

    function addUser($name,$email,$password,$bio,$gender,$user_type)
    {
        $conn = OpenCon();
        $blocked_status = 0;
        $query = "INSERT INTO users(name,email,password,bio,gender,user_type,blocked_status) VALUES('".$name."','".$email."','".$password."','".$bio."','".$gender."','".$user_type."','".$blocked_status."')";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            echo '<script>
                    alert("User added successfully");
                   location.href="usersList.php";
                </script>';
        }
    }

    function getAllUsers()
    {
        $conn = OpenCon();
        $query = "SELECT * FROM users";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function getUserDataById($id)
    {
        $conn = OpenCon();
        $query = "SELECT * FROM users WHERE id = '".$id."'";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function updateUser($id,$name,$email,$password,$bio,$gender,$user_type)
    {
        $conn = OpenCon();
        $query = "UPDATE users SET name = '".$name."', email = '".$email."', password = '".$password."', bio = '".$bio."', gender ='".$gender."', user_type = '".$user_type."' WHERE id = '".$id."' ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            echo '<script>
                    alert("User updated successfully");
                   location.href="usersList.php";
                </script>';
        }
    }

    function blockUser($id)
    {
        $conn = OpenCon();
        $query = "UPDATE users SET blocked_status = 1 WHERE id = '".$id."' ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
           return 1;
        }
    }

    function unBlockUser($id)
    {
        $conn = OpenCon();
        $query = "UPDATE users SET blocked_status = 0 WHERE id = '".$id."' ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
           return 1;
        }
    }

    function getAllAuthors()
    {
        $conn = OpenCon();
        $query = "SELECT * FROM users WHERE user_type = 2 ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function addNovel($name,$author_id)
    {
        $conn = OpenCon();
        $query = "INSERT INTO novels(name,author_id) VALUES('".$name."','".$author_id."')";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            echo '<script>
                    alert("Novel added successfully");
                   location.href="novelsList.php";
                </script>';
        }
    }

    function getAllNovels()
    {
        $conn = OpenCon();
        $query = "SELECT * FROM novels";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function getAuthorDataById($id)
    {
        $conn = OpenCon();
        $query = "SELECT * FROM users WHERE id = '".$id."'";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function addChapter($name, $content, $novel_id)
    {
        $conn = OpenCon();
        $query = "INSERT INTO chapters(name,content,novel_id) VALUES('".$name."','".$content."','".$novel_id."')";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            echo '<script>
                    alert("Chapter added successfully");
                   location.href="chaptersList.php";
                </script>';
        }
    }

    function getAllChapters()
    {
        $conn = OpenCon();
        $query = "SELECT * FROM chapters";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function getNovelDataById($id)
    {
        $conn = OpenCon();
        $query = "SELECT * FROM novels WHERE id = '".$id."'";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function getChapterDataById($id)
    {
        $conn = OpenCon();
        $query = "SELECT * FROM chapters WHERE id = '".$id."'";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return $result;
        }
    }

    function updateChapter($id, $name, $content)
    {
        $conn = OpenCon();
        $query = "UPDATE chapters SET name = '".$name."', content = '".$content."' WHERE id = '".$id."' ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            echo '<script>
                    alert("Chapter updated successfully");
                   location.href="chaptersList.php";
                </script>';
        }
    }

    function deleteChapter($id)
    {
        $conn = OpenCon();
        $query = "DELETE FROM chapters WHERE id = '".$id."' ";
        $result = mysqli_query($conn,$query);
        if($result)
        {
            return 1;
        }
    }

?>