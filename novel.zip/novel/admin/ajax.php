<?php
    include 'functions.php';

    if(!empty($_POST['block_user_id']))
    {
        $user_id = $_POST['block_user_id'];
        $result = blockUser($user_id);
        if($result == 1)
        {
            echo 1;
        }
    }

    if(!empty($_POST['unblock_user_id']))
    {
        $user_id = $_POST['unblock_user_id'];
        $result = unBlockUser($user_id);
        if($result == 1)
        {
            echo 1;
        }
    }

    if(!empty($_POST['delete_chapter_id']))
    {
        $chapter_id = $_POST['delete_chapter_id'];
        $result = deleteChapter($chapter_id);
        if($result == 1)
        {
            echo 1;
        }
    }
?>