<?php
    include 'functions.php';
    getHeader();
    if(empty($_SESSION['user_id']))
    {
      echo "<script>location.href='index.php';</script>";
      exit;
    }
    $novelId = $_GET['row_id'];
?>

<div class="container" style="margin-top:10%;margin-bottom:10%;">
  <h2 class="text-center">Add Chapter</h2>
  <form action="" method="post">
    <div class="form-group">
      <label for="email">Name:</label>
      <input type="text" class="form-control" placeholder="Enter name" name="name">
    </div>
    <div class="form-group">
      <label>Content</label>
      <textarea class="form-control" name="content"></textarea>
    </div>
    <button type="submit" class="btn btn-default" name="submit">Submit</button>
  </form>
</div>

<?php getFooter(); ?>
<?php
    if(isset($_POST['submit']))
    {
        $name = $_POST['name'];
        $content = $_POST['content'];
        addChapter($name,$content,$novelId);
    }
?>