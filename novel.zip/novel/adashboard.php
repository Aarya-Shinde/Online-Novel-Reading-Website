<?php
    include 'functions.php';
    getHeader();
    if(empty($_SESSION['user_id']))
    {
      echo "<script>location.href='index.php';</script>";
      exit;
    }
?>

<div id="overviews" class="section wb">
    <div class="container">
        <div class="section-title row text-center">
            <div class="col-md-8 offset-md-2">
                <h3>Tasks</h3>
            </div>
        </div><!-- end title -->
    
        <div class="row align-items-center">
            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                <div class="card" style="width:260px">
                    <img class="card-img-top" src="images/book.png" alt="Card image">
                    <div class="card-body">
                        <h4 class="card-title">Your Novels</h4>
                        <a href="aNovels.php?row_id=<?php echo $_SESSION['user_id']; ?>" class="btn btn-primary">Novels</a>
                    </div>
                </div>
            </div><!-- end col -->
            <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12">
                <div class="card" style="width:260px">
                    <img class="card-img-top" src="images/book.png" alt="Card image">
                    <div class="card-body">
                    <h4 class="card-title">Add New Novel</h4>
                        <a href="addNovels.php?row_id=<?php echo $_SESSION['user_id']; ?>" class="btn btn-primary">Add Novel</a>
                    </div>
                </div>
            </div><!-- end col -->
        </div>
    </div><!-- end container -->
</div><!-- end section -->

<?php getFooter(); ?>